﻿from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime
import logging

class SchedulerManager:
    def __init__(self, bot, fortnite_api):
        self.bot = bot
        self.fortnite_api = fortnite_api
        self.scheduler = AsyncIOScheduler()
        
    async def publish_shop(self):
        """Публикация магазина в 3:00"""
        try:
            shop_data = await self.fortnite_api.get_shop()
            if shop_data and 'shop' in shop_data:
                # Получаем изображение магазина
                image_url = shop_data.get('shop', {}).get('image', '')
                
                if image_url:
                    date = self.fortnite_api.get_shop_update_date()
                    caption = f"🛍️ Обновленный магазин Fortnite {date}"
                    
                    # Публикуем в канал
                    await self.bot.send_photo(
                        chat_id=Config.CHANNEL_ID,
                        photo=image_url,
                        caption=caption
                    )
                    logging.info(f"Магазин опубликован: {date}")
        except Exception as e:
            logging.error(f"Ошибка при публикации магазина: {e}")
    
    async def publish_news(self):
        """Публикация новостей каждый час"""
        try:
            news_data = await self.fortnite_api.get_news()
            if news_data and 'news' in news_data:
                news = news_data['news']
                
                for item in news[:1]:  # Берем последнюю новость
                    if 'image' in item:
                        caption = f"📰 {item.get('title', 'Новость Fortnite')}\n\n{item.get('body', '')}"
                        
                        await self.bot.send_photo(
                            chat_id=Config.CHANNEL_ID,
                            photo=item['image'],
                            caption=caption[:1024]  # Ограничение Telegram
                        )
                        logging.info("Новость опубликована")
        except Exception as e:
            logging.error(f"Ошибка при публикации новости: {e}")
    
    def start_scheduler(self):
        """Запуск планировщика"""
        # Публикация магазина каждый день в 3:00
        self.scheduler.add_job(
            self.publish_shop,
            CronTrigger(hour=3, minute=0),
            id='daily_shop'
        )
        
        # Публикация новостей каждый час
        self.scheduler.add_job(
            self.publish_news,
            CronTrigger(hour='*', minute=0),
            id='hourly_news'
        )
        
        self.scheduler.start()
        logging.info("Планировщик запущен")